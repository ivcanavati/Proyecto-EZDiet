package com.example.push_notifs_o2021

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
